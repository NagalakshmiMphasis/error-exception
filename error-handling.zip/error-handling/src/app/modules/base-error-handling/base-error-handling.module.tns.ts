import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { NativeScriptCommonModule } from 'nativescript-angular/common';
import { BaseErrorHandlingComponent } from './base-error-handling/base-error-handling.component';

@NgModule({
  declarations: [BaseErrorHandlingComponent],
  imports: [
    NativeScriptCommonModule
  ],
  schemas: [NO_ERRORS_SCHEMA]
})
export class BaseErrorHandlingModule { }
