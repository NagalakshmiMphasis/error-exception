import { Injectable } from '@angular/core';
@Injectable()
export class LogService {
    currentDateTime:Date;
    currentDateTimeString:any;
  logDetails(msg: any) {
    this.currentDateTime = new Date();
    this.currentDateTimeString = this.currentDateTime.toDateString() + " "   + this.currentDateTime.toTimeString();
   console.log(` ${this.currentDateTimeString} :`, msg)
  }
}