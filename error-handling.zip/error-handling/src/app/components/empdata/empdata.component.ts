import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders  } from "@angular/common/http";
import { LogService } from './../../services/log.service';
import { Observable, from } from 'rxjs';
import { EmpService } from './../../services/emp.service';
import { Emp } from '~/app/models/emp';

@Component({
  selector: 'app-empdata',
  templateUrl: './empdata.component.html',
  styleUrls: ['./empdata.component.css']
})
export class EmpdataComponent implements OnInit {

  errormeassage:string;
  username:string = "";
  getname:string;
  ifError:boolean = false;
  successMsg:string;
  DispalyDataInPage:boolean = false;
  empdata:Emp[];
  DateTime:any;
  DispalyLogDetails:boolean = false;
  selectedLang:string = "English";
  submitted=false;
  constructor( private empservice : EmpService, private logservice :LogService, public http: HttpClient ){}
ngOnInit() {
  // console.log("check on load before data")
  // this.empservice.getData().subscribe(data => {
  //   this.empdata = data;
  //    console.log("check on load", data)
  //   //this.DispalyDataInPage = true;
  //    this.empdata= new Array<Emp>();
  //      data.forEach((element, index) => {
  //        let arr = new Emp();
  //        if(index <5){
  //       // arr.title = element.title;
  //        arr.id = element.id;
  //        this.empdata.push(arr);
  //        }
         
  //      });
  //   this.successMsg = "Data dispalyed successfully";
  //  },
  //  (error) =>{
  //    console.log("my error",error)
  //    this.ifError = true;
  //    this.errormeassage = error;
  //  });
}


DispalyData(){
  this.logservice.logDetails(this.username);
  this.DateTime = this.logservice.currentDateTimeString;
  this.getname = this.username;
  this.submitted = true;
  this.DispalyLogDetails = true;
  this.empservice.getData().subscribe(data => {
   this.empdata = data;
    console.log("check on load", data)
   this.DispalyDataInPage = true;
   this.empdata= new Array<Emp>();
      data.forEach((element, index) => {
        let arr = new Emp();
        if(index <5){
        arr.empname = element.employee_name;
        arr.id = element.id;
       // this.empdata.push(arr);
        }
        
      });
   this.successMsg = "Data dispalyed successfully";
  },
  (error) =>{
    console.log("my error",error)
    this.ifError = true;
    this.errormeassage = error;
  });
}

ClearData(){
  this.empdata = [];
  this.DispalyLogDetails =false;
  this.DispalyDataInPage = false;
  this.errormeassage = '';
}
selectOption(selectedValue){
  this.selectedLang = selectedValue;
}
}
