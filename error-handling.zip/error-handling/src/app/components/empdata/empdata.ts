
export class Emp {
    id?: string;
    
    empname:any;
    employeesal:any;
    employeeage:any;
    profileima:any;

    
}
